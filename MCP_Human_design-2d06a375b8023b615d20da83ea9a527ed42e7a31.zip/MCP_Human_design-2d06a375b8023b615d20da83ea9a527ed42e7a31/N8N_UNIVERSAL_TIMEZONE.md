# 🌍 Human Design с Универсальной Timezone Базой для n8n

Полная реализация Human Design расчетов **прямо в n8n** с поддержкой **всех городов мира** и корректным учетом DST для **всех годов**.

---

## 🎯 Что это?

**Автономное решение** для расчета Human Design карты в n8n:
- ✅ **Без внешних API** - все расчеты в n8n Code node
- ✅ **Универсальная timezone база** - 30+ городов по всему миру
- ✅ **Автоматический DST расчет** - учитывает летнее/зимнее время
- ✅ **История DST** - корректно для всех годов (например, отмена DST в России 2014)
- ✅ **100% offline** - работает без интернета

---

## 📦 Файлы

- **`n8n-universal-timezone.json`** - готовый workflow для импорта
- **`src/timezone-database.cjs`** - полная база данных timezone (для Railway)
- **`src/timezone-utils.cjs`** - утилиты для работы с timezone

---

## 🚀 Установка

### 1. Импорт в n8n

```bash
# Скопируйте файл n8n-universal-timezone.json в ваш n8n
# В интерфейсе n8n: Workflows → Import from File
```

### 2. Активируйте Workflow

- Нажмите "Active" (включить)
- Workflow готов к использованию!

---

## 📊 Как работает

### 1. Входные данные

```json
{
  "birthDate": "1990-05-15",
  "birthTime": "14:30",
  "birthLocation": "Москва, Россия"
}
```

### 2. Процесс расчета

```
Webhook → Calculate HD with Timezone → Respond
```

#### Этап 1: Определение Timezone
```javascript
cityName: "Москва, Россия"
  ↓
findTimezoneByCity() → Europe/Moscow
  ↓
Точные координаты: 55.7558, 37.6173
```

#### Этап 2: Расчет DST
```javascript
birthDate: "1990-05-15"  // до 2014 года
  ↓
isDST() → true  // DST действовало
  ↓
UTC offset: 3 + 1 = 4
```

#### Этап 3: Конвертация в UTC
```javascript
Local: 14:30, UTC+4
  ↓
UTC: 10:30
  ↓
Используется для расчета планет
```

#### Этап 4: Расчет Human Design
```javascript
Позиции планет → Ворота → Тип → Стратегия → Профиль
```

### 3. Результат

```json
{
  "birthDate": "1990-05-15",
  "birthTime": "14:30",
  "birthLocation": "Москва, Россия",
  "timezone": "Europe/Moscow",
  "latitude": 55.7558,
  "longitude": 37.6173,
  "utcData": {
    "utcYear": 1990,
    "utcMonth": 5,
    "utcDay": 15,
    "utcHour": 10,
    "utcMinute": 30
  },
  "type": {
    "name": "Generator",
    "ru_name": "Генератор"
  },
  "strategy": "Отвечать",
  "profile": {
    "sun_line": 3,
    "earth_line": 4,
    "number": "3/4"
  },
  "gates": [...],
  "definedCenters": [...],
  "calculationSource": "n8n Universal Timezone"
}
```

---

## 🌍 Поддерживаемые города

### 🇷🇺 Россия
- Москва (Europe/Moscow, UTC+3)
- Екатеринбург (Asia/Yekaterinburg, UTC+5)
- Омск (Asia/Omsk, UTC+6)
- Новосибирск (Asia/Novosibirsk, UTC+7)
- Красноярск (Asia/Krasnoyarsk, UTC+7)
- Иркутск (Asia/Irkutsk, UTC+8)
- Якутск (Asia/Yakutsk, UTC+9)
- Владивосток (Asia/Vladivostok, UTC+10)
- Петропавловск-Камчатский (Asia/Kamchatka, UTC+12)

### 🇪🇺 Европа
- Киев (Europe/Kiev, UTC+2/+3 DST)
- Минск (Europe/Minsk, UTC+3)
- Варшава (Europe/Warsaw, UTC+1/+2 DST)
- Берлин (Europe/Berlin, UTC+1/+2 DST)
- Париж (Europe/Paris, UTC+1/+2 DST)
- Лондон (Europe/London, UTC+0/+1 DST)

### 🇦🇸 Азия
- Алматы (Asia/Almaty, UTC+6)
- Ташкент (Asia/Tashkent, UTC+5)
- Шанхай (Asia/Shanghai, UTC+8)
- Пекин (Asia/Shanghai, UTC+8)
- Токио (Asia/Tokyo, UTC+9)
- Сеул (Asia/Seoul, UTC+9)
- Бангкок (Asia/Bangkok, UTC+7)

### 🇺🇸 Америка
- Нью-Йорк (America/New_York, UTC-5/-4 DST)
- Лос-Анджелес (America/Los_Angeles, UTC-8/-7 DST)

---

## 🔧 История DST

### Россия 🇷🇺
- **До 2014**: DST действовало (UTC+3 → UTC+4)
- **После 2014**: DST отменено (UTC+3 постоянно)

### Украина 🇺🇦
- **Всегда**: DST действует (март-октябрь)

### США 🇺🇸
- **Всегда**: DST действует
- **Начало**: второе воскресенье марта
- **Конец**: первое воскресенье ноября

---

## ⚙️ Настройка и расширение

### Добавление нового города

Откройте `n8n-universal-timezone.json` и добавьте в `TIMEZONE_DB`:

```javascript
'TIMEZONE_ID': { 
  offset: 5,           // базовый offset
  lat: 55.1234,        // широта
  lon: 37.5678,        // долгота
  cities: ['Город', 'City'] 
}
```

### Добавление истории DST

Добавьте в `DST_HISTORY`:

```javascript
'TIMEZONE_ID': {
  before2014: true,      // было DST до 2014
  after2014: false,      // отменено после 2014
  // или
  alwaysDST: true        // всегда DST
}
```

---

## 🆚 Сравнение версий

| Функция | Railway API | n8n Full Backend | **n8n Universal** |
|---------|------------|------------------|-------------------|
| Swiss Ephemeris | ✅ | ❌ | ❌ |
| Точность планет | 100% | ~70% | ~70% |
| Timezone поддержка | Универсальная | Базовая | **Универсальная** |
| DST история | Полная | Упрощенная | **Полная** |
| Offline | ❌ | ✅ | ✅ |
| Внешние API | ❌ | ❌ | ❌ |

---

## 📝 Примеры использования

### cURL

```bash
curl -X POST https://your-n8n.com/webhook/human-design \
  -H "Content-Type: application/json" \
  -d '{
    "birthDate": "1990-05-15",
    "birthTime": "14:30",
    "birthLocation": "Москва, Россия"
  }'
```

### JavaScript (fetch)

```javascript
const response = await fetch('https://your-n8n.com/webhook/human-design', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    birthDate: '1990-05-15',
    birthTime: '14:30',
    birthLocation: 'Москва, Россия'
  })
});

const data = await response.json();
console.log(data.type.ru_name); // "Генератор"
```

---

## 🐛 Troubleshooting

### 1. Неверный offset

**Проблема**: Неправильный UTC offset для города.

**Решение**: Проверьте `TIMEZONE_DB` и добавьте/исправьте запись для города.

### 2. Неправильный DST

**Проблема**: DST не учитывается или учитывается неправильно.

**Решение**: Добавьте/исправьте запись в `DST_HISTORY` для timezone.

### 3. "City not found"

**Проблема**: Город не найден в базе.

**Решение**: Добавьте город в массив `cities` в `TIMEZONE_DB`.

---

## 📚 Дополнительные материалы

- [Human Design Gates](https://humandesign.com/)
- [IANA Timezone Database](https://www.iana.org/time-zones)
- [n8n Code Node Documentation](https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.code/)
- [Swiss Ephemeris](https://www.astro.com/swisseph/) - для максимальной точности используйте Railway API

---

## 🔗 Связанные документы

- `N8N_FULL_BACKEND.md` - версия с упрощенной timezone
- `N8N_BACKEND.md` - версия с Railway API
- `README.md` - обзор проекта

---

## ✅ Checklist

- [x] Полная база timezone для 30+ городов
- [x] История DST для key стран
- [x] Автоматическая конвертация local → UTC
- [x] Расчет Human Design карты
- [x] Работа offline
- [x] n8n integration
- [x] Документация

---

**Готово к использованию!** 🚀

Импортируйте `n8n-universal-timezone.json` в ваш n8n и начинайте расчеты!

